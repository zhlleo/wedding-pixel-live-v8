const $=id=>document.getElementById(id),socket=io();let state=null,authed=false;
const url=location.origin+'/';$('shareUrl').textContent=url;$('qr').src='/qr';
function copyLink(){navigator.clipboard?.writeText(url).then(()=>alert('链接已复制')).catch(()=>prompt('请复制链接',url))}
function login(){socket.emit('host:login',$('password').value,r=>{if(!r.ok){$('loginErr').textContent=r.error;return}authed=true;sessionStorage.setItem('weddingHostPassword',$('password').value);$('login').classList.add('hide');$('dashboard').classList.remove('hide');$('questions').value=r.questions.join('\n');render()})}
function action(a,extra={}){socket.emit('host:action',{action:a,...extra},r=>{if(!r.ok){$('hostErr').textContent=r.error;return}$('hostErr').textContent='';if(a==='questions')alert('题目已保存')})}
function reveal(answer){if(confirm('确定公布「'+(answer==='groom'?'新郎':'新娘')+'」为正确答案？答错或未作答的玩家会被淘汰。'))action('reveal',{answer})}
function confirmAction(a){if(confirm(a==='clear'?'确定清空所有玩家？大家需要重新加入！':'确定让全部玩家复活并从第一题重新开始？'))action(a)}
function saveQuestions(){const q=$('questions').value.split(/\n/).map(s=>s.trim()).filter(Boolean);action('questions',{questions:q})}
function render(){if(!authed||!state)return;const p=state.players,alive=p.filter(x=>x.alive),picked=alive.filter(x=>x.choice);$('question').textContent=state.phase==='lobby'?'等待朋友入场':`第 ${state.round}/${state.total} 题：${state.question}`;
 $('status').textContent=`阶段：${{lobby:'等待入场',question:'正在答题',revealed:'已公布答案',finished:'游戏结束'}[state.phase]} ｜ 已加入 ${p.length}/30 ｜ 存活 ${alive.length} ｜ 已答 ${picked.length}`;
 $('playersList').innerHTML=p.map(x=>`<span class="pill">${x.alive?'💚':'💀'}${escapeHTML(x.name)}${x.choice==='groom'?'🤵':x.choice==='bride'?'👰':''}${x.online?'':'·离线'}</span>`).join('');
 $('start').disabled=state.phase!=='lobby'||!p.length;$('next').disabled=state.phase!=='revealed';$('revealG').disabled=$('revealB').disabled=state.phase!=='question';$('finish').disabled=state.phase==='lobby'||state.phase==='finished';$('editBox').classList.toggle('hide',state.phase!=='lobby');
}
function escapeHTML(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
socket.on('state',s=>{state=s;render()});socket.on('connect',()=>{if(sessionStorage.getItem('weddingHostPassword')){$('password').value=sessionStorage.getItem('weddingHostPassword');login()}});
