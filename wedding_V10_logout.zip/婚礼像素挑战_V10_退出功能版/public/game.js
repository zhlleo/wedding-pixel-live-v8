const $=id=>document.getElementById(id),socket=io();let state=null,myId=localStorage.getItem('weddingId'),token=localStorage.getItem('weddingToken'),gender='male',lastPhase='',lastEliminated=[];
const cv=$('scene'),ctx=cv.getContext('2d');ctx.imageSmoothingEnabled=false;const W=900,H=670;
const assets={};for(let i=0;i<24;i++){let img=new Image();img.src='/assets/guest'+i+'.png';assets['guest'+i]=img}for(const n of ['bride','groom']){let im=new Image();im.src='/assets/'+n+'.png';assets[n]=im}
const bg=new Image();bg.src='/assets/background.webp';
function setGender(g){gender=g;$('male').classList.toggle('active',g==='male');$('female').classList.toggle('active',g==='female')}
function join(){socket.emit('join',{name:$('nickname').value,gender,token},r=>{if(!r.ok){$('joinErr').textContent=r.error;return}myId=r.id;token=r.token;localStorage.setItem('weddingId',myId);localStorage.setItem('weddingToken',token);$('join').classList.add('hide');$('game').classList.remove('hide');render()})}
function leaveGame(){
 if(!confirm('确定退出当前角色吗？退出后会删除本局角色记录；游戏开始后不能重新加入，需等主持人重开大厅。'))return;
 const oldToken=token;
 // 先清除本机身份，避免刷新后自动恢复旧角色。
 localStorage.removeItem('weddingId');localStorage.removeItem('weddingToken');
 token=null;myId=null;lastEliminated=[];pos.clear();
 $('game').classList.add('hide');$('join').classList.remove('hide');
 $('nickname').value='';$('joinErr').textContent='';
 socket.emit('leave',{token:oldToken},r=>{
  if(!r?.ok){$('joinErr').textContent='本机已退出；服务器未能删除旧角色：'+(r?.error||'网络异常')+'。请联系主持人清空玩家后重试。';}
 });
}
function answer(v){socket.emit('answer',v,r=>{if(!r.ok)alert(r.error)})}
socket.on('connect',()=>{if(token)socket.emit('join',{token},r=>{if(r.ok){myId=r.id;$('join').classList.add('hide');$('game').classList.remove('hide');render()}else{token=null;myId=null;localStorage.removeItem('weddingToken');$('join').classList.remove('hide');$('game').classList.add('hide')}})});
socket.on('state',s=>{if(s.phase==='revealed'&&lastPhase!=='revealed')lastEliminated=s.eliminated;state=s;lastPhase=s.phase;render();updateTimer()});
function render(){if(!state)return;const p=state.players,me=p.find(x=>x.id===myId),alive=p.filter(x=>x.alive),g=alive.filter(x=>x.choice==='groom').length,b=alive.filter(x=>x.choice==='bride').length;
 $('identity').textContent=me?'🎮 '+me.name+(me.alive?' · 仍在游戏中':' · 已被淘汰，继续观战'):'等待身份同步';
 $('question').textContent=state.phase==='lobby'?'🌷 等待新郎开始游戏…':state.phase==='finished'?'🏆 游戏结束':`第 ${state.round}/${state.total} 题 · ${state.question}`;
 $('stats').textContent=`🤵 新郎阵营 ${g} 人 · 👰 新娘阵营 ${b} 人 · 💚 存活 ${alive.length}/${p.length}`;
 const msg={lobby:'已入场！等待朋友们加入',question:me?.choice?'已选择'+(me.choice==='groom'?'新郎':'新娘')+'，公布前可以改选':'请选一边站队！',revealed:'正确答案：'+(state.answer==='groom'?'🤵 新郎':'👰 新娘')+'！本轮淘汰 '+state.eliminated.length+' 人',finished:'谢谢大家参与！'};
 $('status').textContent=msg[state.phase]||'';$('answerBtns').classList.toggle('hide',state.phase!=='question'||!me?.alive);
 $('pickG').classList.toggle('active',me?.choice==='groom');$('pickB').classList.toggle('active',me?.choice==='bride');
 $('winner').textContent=state.phase==='finished'?(state.winner.length?'🎉 恭喜 '+p.filter(x=>state.winner.includes(x.id)).map(x=>x.name).join('、')+' 获胜！':'💫 全员淘汰！新郎可以重新开局') :'';
}
const pos=new Map(),petals=Array.from({length:38},(_,i)=>({x:(i*127)%900,y:(i*97)%670,s:2+i%4}));
function rect(x,y,w,h,color){ctx.fillStyle=color;ctx.fillRect(x,y,w,h)}
function text(s,x,y,size=19,color='#684258'){ctx.font=`bold ${size}px system-ui`;ctx.textAlign='center';ctx.lineWidth=4;ctx.strokeStyle='#fff8ee';ctx.strokeText(s,x,y);ctx.fillStyle=color;ctx.fillText(s,x,y)}
function drawImg(name,x,y,w,h){let im=assets[name];if(im?.complete&&im.naturalWidth)ctx.drawImage(im,x-w/2,y-h,w,h)}
function loop(t){ctx.clearRect(0,0,W,H);if(bg.complete&&bg.naturalWidth)ctx.drawImage(bg,0,0,W,H);else{rect(0,0,W,H,'#c6e7ed');rect(0,340,W,330,'#e5b8a7')}
 ctx.fillStyle='#a8d9f0b9';ctx.fillRect(22,327,420,313);ctx.fillStyle='#f5adc5b9';ctx.fillRect(458,327,420,313);
 ctx.strokeStyle='#fff7df';ctx.lineWidth=6;ctx.strokeRect(22,327,420,313);ctx.strokeRect(458,327,420,313);
 text('🤵 新郎阵营',227,360,23,'#376d9a');text('👰 新娘阵营',674,360,23,'#ae577d');
 drawImg('groom',230,324,102,160);drawImg('bride',670,324,118,166);
 if(state){const arr=state.players;for(const p of arr){let x,y;if(!p.alive){x=p.choice==='groom'?-95:995;y=490}else if(p.choice){let team=arr.filter(q=>q.alive&&q.choice===p.choice),i=team.findIndex(q=>q.id===p.id);x=(p.choice==='groom'?58:493)+(i%7)*53;y=420+Math.floor(i/7)*65}else{let neutral=arr.filter(q=>q.alive&&!q.choice),i=neutral.findIndex(q=>q.id===p.id);x=70+(i%14)*57;y=595+Math.floor(i/14)*34}
 let v=pos.get(p.id);if(!v){v={x:450,y:560};pos.set(p.id,v)}v.x+=(x-v.x)*.085;v.y+=(y-v.y)*.085;
 if(v.x<-60||v.x>960)continue;
 const bob=Math.abs(v.x-x)>2?Math.sin(t/95+v.x)*3:Math.sin(t/500+v.x)*1.5;
 drawImg('guest'+p.avatar,v.x,v.y+bob,42,62);
 const label=p.name;ctx.font='bold 14px system-ui';let wid=Math.min(88,Math.max(40,ctx.measureText(label).width+12));rect(v.x-wid/2,v.y-79+bob,wid,21,p.id===myId?'#fff5aa':'#fff9f0');text(label,v.x,v.y-63+bob,14,p.id===myId?'#a23b60':'#674859');
 }}
 for(const a of petals){let y=(a.y+t*.012*(a.s/3))%H;rect((a.x+Math.sin(t/1500+a.y)*18)%W,y,a.s,a.s,'#fff3d7b0')}
 requestAnimationFrame(loop)}requestAnimationFrame(loop);

// 服务器时间戳为准，所有手机同步显示倒计时。
function updateTimer(){
 const el=document.getElementById('timer');if(!el||!state)return;
 const active=state.phase==='question'&&Number.isFinite(state.deadline);
 el.classList.toggle('hide',!active);
 if(!active)return;
 const remaining=Math.max(0,Math.ceil((state.deadline-Date.now())/1000));
 el.textContent=remaining?'⏳ 剩余 '+remaining+' 秒':'⏰ 时间到，等待公布答案';
 el.classList.toggle('urgent',remaining<=5);
 const me=state.players.find(p=>p.id===myId);
 document.getElementById('answerBtns').classList.toggle('hide',remaining===0||!me?.alive);
 }
setInterval(updateTimer,200);
